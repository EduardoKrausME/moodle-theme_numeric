# theme_numeric
Desenvolvi este thema e estou disponibilizando gratuitamente para uso.

Testei na versão 2.7.

# Trocar as cores

## É possível trocar a Logo?

Sim, É só enviar uma nova imagem, JPG, GIF ou PNG que será substituido.
![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/conf-1.png)

## É possível trocar a cor dos Links?

Sim, conforme imagem abaixo é possível trocar as cores dos links do thema.
![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/conf-2.png)

## É possível trocar a cor dos Cabechalhos?

Sim, conforme imagem abaixo é possível trocar as cores dos cabechalhos do thema.
![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/conf-3.png)

## E Mudar o texto do rodapé?

Também há uma configuração para trocar o texto do rodapé. 
![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/conf-4.png)

## E o CSS?

Podes também adicionar CSS customizados ao thema que se sobrepoe a todo o moodle.
![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/conf-5.png)

# Print Screen

![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/moodle-3.png)

![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/moodle-1.png)

![alt tag](https://raw.githubusercontent.com/EduardoKrausME/theme_numeric/master/print/moodle-2.png)

